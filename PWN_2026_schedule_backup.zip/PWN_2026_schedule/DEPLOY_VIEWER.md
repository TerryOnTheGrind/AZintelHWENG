# Deploying the published viewer & editor (multi-user, persistent accounts)

Two Streamlit Cloud apps share one Google Sheet for user accounts:

- **Viewer** (`streamlit_viewer.py`) — read-only, open registration. Anyone
  with an account can see the live schedule.
- **Editor** (`streamlit_app.py`) — full-featured dashboard. Same sign-in
  flow, but additionally restricted to usernames listed in
  `[admins].usernames` in Streamlit Secrets.

Both apps need the same Google Sheet + service-account secrets. Set up the
sheet once; deploy each app pointing at it.

Final architecture:

```
viewers' browsers ──► Streamlit Cloud (streamlit_viewer.py)  ◄── read-only
                          │
admins' browsers ───► Streamlit Cloud (streamlit_app.py)     ◄── editor (admin allowlist)
                          │
                          │ both read/write Users tab
                          ▼
                  Google Sheet (Users tab)
                          │
                  service-account credentials
                  in Streamlit Cloud Secrets
```

**About persistence in the editor:** Streamlit Cloud's filesystem is wiped
on every restart, so the editor's `schedule_state.json` saves only persist
**within a single session**. To publish your edits to the viewer, commit
the updated `schedule_state.json` back to the repo — Streamlit Cloud
auto-redeploys both apps on every push (~1 min). For a tournament weekend,
keep one editor session open the whole time and only push when you want
the viewer updated.

---

## One-time setup checklist

### 1. Push the repo to GitHub

You need to commit the project to a GitHub repo so Streamlit Cloud can pull it.

If you haven't installed Git tools, the simplest route is **GitHub Desktop**:

1. Download from https://desktop.github.com and install.
2. Sign in with your GitHub account (or create one at https://github.com/signup).
3. **File → Add Local Repository →** point at `c:\Claude\PWN_2026_schedule`.
   Desktop will offer to initialize it as a repo — accept.
4. Make sure these are committed:
   - `streamlit_viewer.py`
   - `schedule_state.json`
   - `requirements.txt`
   - `.gitignore` (already excludes `auth.json`, `secrets.toml`, etc.)
5. Click **Publish repository** (top-right). Pick a name like
   `pwn-2026-viewer`. Keep it private if you'd rather.

If you prefer the web UI: create a new empty repo at https://github.com/new,
then drag-and-drop the project files in via the browser uploader.

### 2. Create a Google Cloud service account (for Sheets access)

1. Go to https://console.cloud.google.com and sign in with the Google account
   you want to own this. (You can use your existing Gmail.)
2. Create a new project: **Project picker (top bar) → New Project →**
   name it `pwn-viewer`, click Create.
3. Enable two APIs for that project:
   - https://console.cloud.google.com/apis/library/sheets.googleapis.com → Enable
   - https://console.cloud.google.com/apis/library/drive.googleapis.com → Enable
4. Create the service account:
   - Go to https://console.cloud.google.com/iam-admin/serviceaccounts
   - **Create service account** → name it `pwn-viewer-sa` → **Create and continue**
   - Skip the "grant access to project" step (Done).
5. Generate a JSON key:
   - Click the new service account → **Keys** tab → **Add key** → **Create new key** → **JSON** → Create.
   - A JSON file downloads. **This is the only copy** — save it somewhere safe.
   - Note the `client_email` field inside the JSON (looks like
     `pwn-viewer-sa@pwn-viewer.iam.gserviceaccount.com`).

### 3. Create the Users Google Sheet

1. Go to https://sheets.new (creates a new sheet).
2. Name it something like **PWN Viewer Users**.
3. Rename the first tab to **Users** (matters — the code looks for that name).
4. In row 1, paste this header (one column each):
   ```
   username	email	password_hash	salt_hex	iterations	hash	created_at
   ```
5. Share the sheet with the service account: **Share** button → paste the
   `client_email` from step 2 → set to **Editor** → uncheck "Notify people" → Send.
6. From the URL, copy the **sheet ID**. It's the long string between
   `/d/` and `/edit`, e.g.
   `https://docs.google.com/spreadsheets/d/`**`1AbCdEfGhIjKlMn...`**`/edit#gid=0`

### 4. Deploy the **viewer** on Streamlit Community Cloud

1. Go to https://share.streamlit.io and click **New app**.
2. Pick your GitHub repo, branch `main`, main file `streamlit_viewer.py`.
3. Pick a custom URL like `pwn-2026-schedule`.
4. Click **Deploy**. First boot will fail because secrets aren't set yet —
   that's expected.
5. Once the app shows up: open the **⋮** menu on the app's row → **Settings →
   Secrets**, and paste this template, filling in your values:

   ```toml
   [smtp]
   host = "smtp.gmail.com"
   port = 465
   user = "terrence.poole@gmail.com"
   password = "ckgg olih lfqu zkom"
   from_name = "Terry's Event Schedule"

   [gsheets]
   sheet_id = "1AbCdEfGhIjKlMn..."   # the long ID from your sheet's URL

   [gcp_service_account]
   # Open the JSON file you downloaded in step 2.5 and translate it.
   # Each top-level key in the JSON becomes a key in this TOML table.
   # The "private_key" field contains literal "\n" sequences — paste it
   # as a triple-quoted string so the newlines stay intact.
   type = "service_account"
   project_id = "pwn-viewer"
   private_key_id = "abcd1234..."
   private_key = """-----BEGIN PRIVATE KEY-----
   MII...long...stuff...with...real...line...breaks...
   -----END PRIVATE KEY-----
   """
   client_email = "pwn-viewer-sa@pwn-viewer.iam.gserviceaccount.com"
   client_id = "1234567890"
   auth_uri = "https://accounts.google.com/o/oauth2/auth"
   token_uri = "https://oauth2.googleapis.com/token"
   auth_provider_x509_cert_url = "https://www.googleapis.com/oauth2/v1/certs"
   client_x509_cert_url = "https://www.googleapis.com/..."
   universe_domain = "googleapis.com"
   ```

6. Click **Save**. The app reboots automatically (~30 seconds).

7. Visit the public URL. You'll see Sign in / Create account tabs. Register
   yourself first to verify the flow, then check the Google Sheet — your row
   should appear.

### 5. Deploy the **editor** on Streamlit Community Cloud

The editor is the same repo, just a different entry point — `streamlit_app.py`.
It uses the same Google Sheet and the same service-account credentials, plus
an extra `[admins]` block listing which usernames are allowed to sign in.

1. Back at https://share.streamlit.io, click **New app** again.
2. Same GitHub repo, branch `main`, but main file `streamlit_app.py`.
3. Pick a custom URL like `pwn-2026-editor` (keep it different from the viewer).
4. Click **Deploy** — first boot will fail until secrets are set.
5. Open the new app's **Settings → Secrets** and paste **the same secrets
   block as the viewer**, then add this extra section at the end:

   ```toml
   [admins]
   # Only these usernames can sign in to the editor, even if they have a
   # registered account in the viewer's Users sheet. Case-insensitive.
   usernames = ["terry"]
   ```

   You can list multiple admins: `usernames = ["terry", "alice", "bob"]`.

6. Click **Save**. The app reboots (~30 seconds).

7. Visit the editor's URL. Sign in with your admin username (the same
   account you registered through the viewer — they share the Users sheet).
   You'll land on the full editor dashboard.

**Important — editor edits are session-scoped.** Streamlit Cloud wipes
the filesystem on restart, so saves to `schedule_state.json` only persist
during your live session. To publish your changes to the public viewer,
commit `schedule_state.json` back to the repo (e.g. via GitHub Desktop).
The viewer auto-reloads from the new file within ~1 minute of the push.

---

## Updating the schedule visible to viewers

The viewer reads `schedule_state.json` from the deployed repo. To push an
updated schedule live: commit and push a fresh `schedule_state.json`.
Streamlit Cloud auto-redeploys on every push (~1 min downtime).

For TRUE live sync (laptop simulator → public viewer in real time), we'd need
to also move `schedule_state.json` and `sim_state.json` into a shared store.
That's a bigger refactor — let me know if you want to pursue it.

---

## Managing users

Open the Google Sheet directly. Each registered user is a row. To revoke
access, delete the row (users with no row in the sheet can't sign in).
To rename a user, edit the username cell directly.

---

## Concurrent-user limits

Streamlit Community Cloud's free tier is rate-limited; expect smooth
performance for ~50 concurrent viewers. If you anticipate 100+ during the
event, you'll want to upgrade to Streamlit Cloud Teams (paid) or move to a
larger host like Render or Fly.io.
