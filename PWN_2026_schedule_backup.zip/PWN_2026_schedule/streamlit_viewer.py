"""
Read-only schedule viewer — single-file Streamlit app for deployment to
Streamlit Community Cloud, with persistent multi-user accounts backed by a
Google Sheet (so accounts survive Streamlit Cloud's ephemeral filesystem).

Auth flow (mirrors the local viewer.py):
    1. New user fills in username / email / password.
    2. App emails a 6-digit code via Gmail SMTP (st.secrets["smtp"]).
    3. User enters the code → row written to the Users sheet (hashed password).
    4. Future visits: username + password → checked against the sheet.

Setup checklist (one-time):
    GitHub:
        - Push this folder to GitHub.
    Google Cloud + Sheets:
        - Create a service account, download its JSON key.
        - Create a Google Sheet, share it with the service account's email
          (Editor permission). Note the sheet ID (the long string in its URL).
        - Add a "Users" tab with header row:
              username | email | password_hash | salt_hex | iterations | hash | created_at
    Streamlit Community Cloud (Settings → Secrets):
        [smtp]
        host = "smtp.gmail.com"
        port = 465
        user = "you@gmail.com"
        password = "16-char-app-password"
        from_name = "Terry's Event Schedule"

        [gsheets]
        sheet_id = "1AbC...your-sheet-id..."

        [gcp_service_account]
        # Paste the entire contents of the service-account JSON here as a TOML table.

requirements.txt must include:
    streamlit>=1.37
    pandas>=2.0
    gspread>=6.0
    google-auth>=2.30
"""

from __future__ import annotations

import base64
import hashlib
import html
import json
import re
import secrets as _secrets
import smtplib
import ssl
import time
from datetime import datetime, timezone
from email.message import EmailMessage
from pathlib import Path

import pandas as pd
import streamlit as st


APP_DIR = Path(__file__).parent
STATE_PATH = APP_DIR / "schedule_state.json"
SIM_STATE_PATH = APP_DIR / "sim_state.json"
LION_PATH = APP_DIR / "lion.webp"


@st.cache_resource(show_spinner=False)
def _lion_data_uri():
    if not LION_PATH.exists():
        return None
    b64 = base64.b64encode(LION_PATH.read_bytes()).decode("ascii")
    return f"data:image/webp;base64,{b64}"


def _normalize_name(raw):
    """Normalize an athlete name: each word starts with an uppercase letter,
    the rest lowercase; collapse whitespace to single spaces. Handles
    middle names by treating each whitespace-separated token independently.
    Apostrophes and hyphens within a word stay lowercased after the first
    letter (e.g. "O'connor", "smith-jones") — adjust here if you need
    "O'Connor"/"Smith-Jones" behavior.
    """
    if raw is None:
        return ""
    s = str(raw).strip()
    if not s:
        return s
    parts = s.split()
    return " ".join(p[:1].upper() + p[1:].lower() for p in parts if p)

ALL_RINGS = [
    "Sanda Ring", "Open Mat", "Lion Dance Stage",
    "Ring 1", "Ring 2", "Ring 3", "Ring 4", "Ring 5",
]
EVENT_DAYS = ["Saturday", "Sunday"]
RING_SLOT_MINUTES = {"Lion Dance Stage": 15}
DEFAULT_SLOT = 5

RING_ICONS = {
    "Sanda Ring": "🥊",
    "Open Mat": "✊",
    "Lion Dance Stage": "🐉",
    "Ring 1": "🔴",
    "Ring 2": "🟠",
    "Ring 3": "🟡",
    "Ring 4": "🟢",
    "Ring 5": "🔵",
}
RING_BORDER_COLORS = {
    "Ring 1": "#E74C3C",
    "Ring 2": "#E67E22",
    "Ring 3": "#F1C40F",
    "Ring 4": "#27AE60",
    "Ring 5": "#3498DB",
}


def _inject_ring_button_styles():
    """Per-ring border colors via Streamlit's `st-key-<key>` class hook."""
    if st.session_state.get("_ring_button_css_done"):
        return
    css = [
        '[class*="st-key-vw-ringbtn-"] button {'
        '  border-width: 3px !important;'
        '  border-radius: 14px !important;'
        '  font-weight: 600 !important;'
        '  padding: 0.5rem 0.4rem !important;'
        '  min-height: 3.2rem !important;'
        '}',
    ]
    for ring, color in RING_BORDER_COLORS.items():
        slug = ring.replace(" ", "_")
        css.append(
            f'[class*="st-key-vw-ringbtn-{slug}"] button {{'
            f'  border-color: {color} !important;'
            f'}}'
        )
        css.append(
            f'[class*="st-key-vw-ringbtn-{slug}"] button:hover {{'
            f'  background-color: {color}22 !important;'
            f'  border-color: {color} !important;'
            f'  color: inherit !important;'
            f'}}'
        )
    st.markdown(f"<style>\n{chr(10).join(css)}\n</style>", unsafe_allow_html=True)
    st.session_state._ring_button_css_done = True


def _label_for_ring(ring):
    icon = RING_ICONS.get(ring, "")
    return f"{icon}  {ring}".strip()

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
CODE_TTL_SECONDS = 15 * 60
PBKDF2_ITERATIONS = 310_000
PBKDF2_HASH = "sha256"

USERS_SHEET = "Users"
USERS_HEADER = ["username", "email", "password_hash", "salt_hex", "iterations", "hash", "created_at"]

st.set_page_config(
    page_title="Terry's Event Schedule — Live View",
    page_icon="📋",
    layout="wide",
)

# ----- Decorative background (warm gradient + lion watermark) -----
_lion_uri = _lion_data_uri()
_lion_bg_layer = (
    f"url('{_lion_uri}') center center / min(60vw, 720px) no-repeat fixed,"
    if _lion_uri else ""
)
st.markdown(
    f"""
    <style>
    .stApp {{
      background:
        {_lion_bg_layer}
        radial-gradient(circle at 0% 0%, rgba(255,200,140,0.55) 0%, transparent 35%),
        radial-gradient(circle at 100% 100%, rgba(255,180,200,0.50) 0%, transparent 35%),
        linear-gradient(135deg, #fff8ef 0%, #fff2dc 45%, #ffe8d0 100%);
    }}
    /* Wash the lion behind a translucent overlay so the schedule grid stays
       readable — it's flair, not a focal point. */
    .stApp::before {{
      content: "";
      position: fixed;
      inset: 0;
      background: rgba(255, 248, 239, 0.78);
      pointer-events: none;
      z-index: 0;
    }}
    .stApp > * {{ position: relative; z-index: 1; }}
    .pwn-deco {{
      position: fixed;
      z-index: 9999;
      pointer-events: none;
      user-select: none;
      opacity: 0.22;
      filter: drop-shadow(0 4px 8px rgba(0,0,0,0.18));
      transition: opacity 0.3s ease;
    }}
    .pwn-deco:hover {{ opacity: 0.45; }}
    .pwn-deco.br {{
      bottom: 0.5rem;
      right: 0.5rem;
      font-size: 8rem;
      transform: rotate(12deg);
    }}
    @media (max-width: 900px) {{
      .pwn-deco {{ display: none; }}
      .stApp {{ background-size: 70vw; }}
    }}
    </style>
    <div class="pwn-deco br" title="Flower">🌸</div>
    """,
    unsafe_allow_html=True,
)


# ---------- Google Sheets backend ----------
@st.cache_resource(show_spinner=False)
def _open_users_sheet():
    """Return a gspread Worksheet for the Users tab, or None if unconfigured."""
    try:
        sa_info = dict(st.secrets["gcp_service_account"])
        sheet_id = st.secrets["gsheets"]["sheet_id"]
    except (FileNotFoundError, KeyError, AttributeError):
        return None
    try:
        import gspread
        from google.oauth2.service_account import Credentials
    except ImportError:
        return None
    scopes = [
        "https://www.googleapis.com/auth/spreadsheets",
        "https://www.googleapis.com/auth/drive",
    ]
    creds = Credentials.from_service_account_info(sa_info, scopes=scopes)
    client = gspread.authorize(creds)
    sh = client.open_by_key(sheet_id)
    try:
        ws = sh.worksheet(USERS_SHEET)
    except Exception:
        ws = sh.add_worksheet(title=USERS_SHEET, rows=1000, cols=len(USERS_HEADER))
        ws.append_row(USERS_HEADER, value_input_option="RAW")
    # Make sure the header row exists.
    if not ws.row_values(1):
        ws.append_row(USERS_HEADER, value_input_option="RAW")
    return ws


def _users_df():
    ws = _open_users_sheet()
    if ws is None:
        return None
    rows = ws.get_all_records()
    df = pd.DataFrame(rows)
    # Make missing columns explicit so lookups don't KeyError.
    for c in USERS_HEADER:
        if c not in df.columns:
            df[c] = ""
    return df


def _find_user(username):
    df = _users_df()
    if df is None or df.empty:
        return None
    m = df["username"].astype(str).str.strip().str.lower() == username.strip().lower()
    if not m.any():
        return None
    return df[m].iloc[-1].to_dict()  # most recent if duplicates somehow


def _username_or_email_taken(username, email):
    df = _users_df()
    if df is None or df.empty:
        return False
    u = df["username"].astype(str).str.strip().str.lower() == username.strip().lower()
    e = df["email"].astype(str).str.strip().str.lower() == email.strip().lower()
    return bool((u | e).any())


def _append_user(username, email, password):
    ws = _open_users_sheet()
    if ws is None:
        raise RuntimeError("User store not configured.")
    salt = _secrets.token_bytes(16)
    pw_hash = _hash_password(password, salt)
    ws.append_row([
        username,
        email,
        pw_hash,
        salt.hex(),
        PBKDF2_ITERATIONS,
        PBKDF2_HASH,
        datetime.now(timezone.utc).isoformat(),
    ], value_input_option="RAW")


def _update_user_password(username, new_password):
    """Find the row for `username` and rewrite its password_hash + salt_hex."""
    ws = _open_users_sheet()
    if ws is None:
        raise RuntimeError("User store not configured.")
    records = ws.get_all_records()
    target_row = None
    for i, rec in enumerate(records, start=2):  # row 1 is header
        if str(rec.get("username", "")).strip().lower() == username.strip().lower():
            target_row = i
            break
    if target_row is None:
        raise RuntimeError(f"User {username!r} not found.")
    salt = _secrets.token_bytes(16)
    pw_hash = _hash_password(new_password, salt)
    ws.update_cell(target_row, 3, pw_hash)
    ws.update_cell(target_row, 4, salt.hex())
    ws.update_cell(target_row, 5, PBKDF2_ITERATIONS)
    ws.update_cell(target_row, 6, PBKDF2_HASH)


def _hash_password(password, salt):
    return hashlib.pbkdf2_hmac(
        PBKDF2_HASH, password.encode("utf-8"), salt, PBKDF2_ITERATIONS
    ).hex()


def _verify(password, record):
    if not record:
        return False
    salt_hex = record.get("salt_hex") or ""
    if not salt_hex:
        return False
    candidate = _hash_password(password, bytes.fromhex(salt_hex))
    return _secrets.compare_digest(candidate, str(record.get("password_hash", "")))


# ---------- Email ----------
def _send_password_reset_email(to_email, code):
    try:
        smtp_cfg = st.secrets.get("smtp")
    except (FileNotFoundError, AttributeError):
        smtp_cfg = None
    if not smtp_cfg or not smtp_cfg.get("user") or not smtp_cfg.get("password"):
        return (False, "SMTP not configured — code shown on screen.")
    host = smtp_cfg.get("host", "smtp.gmail.com")
    port = int(smtp_cfg.get("port", 465))
    user = smtp_cfg["user"]
    password = smtp_cfg["password"]
    from_name = smtp_cfg.get("from_name", "Terry's Event Schedule")
    msg = EmailMessage()
    msg["Subject"] = "Your password reset code"
    msg["From"] = f"{from_name} <{user}>"
    msg["To"] = to_email
    msg.set_content(
        f"Your password reset code is: {code}\n\n"
        f"Enter this code in the dashboard to set a new password.\n"
        f"It expires in 15 minutes.\n\n"
        f"If you didn't request this, ignore this email — your password "
        f"will not change.\n"
    )
    try:
        ctx = ssl.create_default_context()
        if port == 465:
            with smtplib.SMTP_SSL(host, port, context=ctx, timeout=20) as srv:
                srv.login(user, password)
                srv.send_message(msg)
        else:
            with smtplib.SMTP(host, port, timeout=20) as srv:
                srv.ehlo()
                srv.starttls(context=ctx)
                srv.ehlo()
                srv.login(user, password)
                srv.send_message(msg)
        return (True, f"Password reset code sent to {to_email}.")
    except Exception as e:
        return (False, f"Email send failed ({type(e).__name__}: {e}). Code shown on screen.")


def _send_confirmation_email(to_email, code):
    try:
        smtp_cfg = st.secrets.get("smtp")
    except (FileNotFoundError, AttributeError):
        smtp_cfg = None
    if not smtp_cfg or not smtp_cfg.get("user") or not smtp_cfg.get("password"):
        return (False, "SMTP not configured — code shown on screen.")

    host = smtp_cfg.get("host", "smtp.gmail.com")
    port = int(smtp_cfg.get("port", 465))
    user = smtp_cfg["user"]
    password = smtp_cfg["password"]
    from_name = smtp_cfg.get("from_name", "Terry's Event Schedule")

    msg = EmailMessage()
    msg["Subject"] = "Your viewer dashboard confirmation code"
    msg["From"] = f"{from_name} <{user}>"
    msg["To"] = to_email
    msg.set_content(
        f"Your confirmation code is: {code}\n\n"
        f"Enter this code in the dashboard to finish creating your account.\n"
        f"It expires in 15 minutes.\n"
    )

    try:
        ctx = ssl.create_default_context()
        if port == 465:
            with smtplib.SMTP_SSL(host, port, context=ctx, timeout=20) as srv:
                srv.login(user, password)
                srv.send_message(msg)
        else:
            with smtplib.SMTP(host, port, timeout=20) as srv:
                srv.ehlo()
                srv.starttls(context=ctx)
                srv.ehlo()
                srv.login(user, password)
                srv.send_message(msg)
        return (True, f"Confirmation code sent to {to_email}.")
    except Exception as e:
        return (False, f"Email send failed ({type(e).__name__}: {e}). Code shown on screen.")


# ---------- Auth UI ----------
def _render_login():
    tab_login, tab_register, tab_reset = st.tabs(
        ["Sign in", "Create account", "Forgot password"]
    )

    with tab_login:
        st.caption("Read-only dashboard. Sign in with the account you registered.")
        with st.form("login_form"):
            u = st.text_input("Username")
            p = st.text_input("Password", type="password")
            ok = st.form_submit_button("Sign in", type="primary")
        if ok:
            rec = _find_user(u)
            if _verify(p, rec):
                st.session_state.auth_user = rec["username"]
                st.rerun()
            else:
                st.error("Invalid username or password.")

    with tab_register:
        _render_register()

    with tab_reset:
        _render_reset()


def _render_reset():
    pending = st.session_state.get("reset_pending")

    if not pending:
        st.caption(
            "Forgot your password? Enter your username and we'll email a "
            "6-digit code to the address on file."
        )
        with st.form("reset_request_form"):
            u = st.text_input("Username", key="reset_username")
            ok = st.form_submit_button("Send reset code", type="primary")
        if ok:
            if not u.strip():
                st.error("Username is required.")
                return
            try:
                rec = _find_user(u)
            except Exception as err:
                st.error(f"Couldn't reach the user database: {err}")
                return
            # Always show the same confirmation message regardless of whether
            # the username exists, so attackers can't enumerate accounts.
            generic_msg = (
                "If an account exists for that username, a reset code has "
                "been emailed to the address on file. The code expires in "
                "15 minutes."
            )
            if not rec or not rec.get("email"):
                st.success(generic_msg)
                return
            email = str(rec["email"]).strip()
            code = f"{_secrets.randbelow(1_000_000):06d}"
            sent, msg = _send_password_reset_email(email, code)
            st.session_state.reset_pending = {
                "username": rec["username"],
                "email": email,
                "code": code,
                "expires_at": time.time() + CODE_TTL_SECONDS,
                "delivery": "email" if sent else "onscreen",
                "delivery_msg": msg,
            }
            st.rerun()
        return

    if time.time() > pending["expires_at"]:
        st.error("That reset code expired. Start over.")
        if st.button("Start over", key="reset_restart"):
            st.session_state.pop("reset_pending", None)
            st.rerun()
        return

    if pending["delivery"] == "email":
        # Don't reveal the email address to whoever is at the keyboard —
        # they may not be the account owner.
        st.success("A reset code has been emailed to the address on file.")
    else:
        st.warning(pending["delivery_msg"])
        st.info(f"Reset code: **{pending['code']}** (valid for 15 minutes)")

    with st.form("reset_confirm_form"):
        code_in = st.text_input("Enter 6-digit code", max_chars=6, key="reset_code_in")
        np1 = st.text_input("New password", type="password", key="reset_pw1")
        np2 = st.text_input("Confirm new password", type="password", key="reset_pw2")
        c1, c2 = st.columns(2)
        with c1:
            confirm = st.form_submit_button("Set new password", type="primary")
        with c2:
            cancel = st.form_submit_button("Cancel")
    if cancel:
        st.session_state.pop("reset_pending", None)
        st.rerun()
    if confirm:
        if not _secrets.compare_digest(code_in.strip(), pending["code"]):
            st.error("That code doesn't match.")
            return
        if len(np1) < 6:
            st.error("Password must be at least 6 characters.")
            return
        if np1 != np2:
            st.error("Passwords do not match.")
            return
        try:
            _update_user_password(pending["username"], np1)
        except Exception as err:
            st.error(f"Couldn't update your password: {err}")
            return
        st.session_state.pop("reset_pending", None)
        st.success("Password updated. Switch to the Sign in tab and use your new password.")


def _render_register():
    pending = st.session_state.get("setup_pending")

    if not pending:
        st.caption("Create an account. We'll email a 6-digit code to confirm.")
        with st.form("register_form"):
            u = st.text_input("Username", key="reg_username")
            e = st.text_input("Email", key="reg_email")
            p1 = st.text_input("Password", type="password", key="reg_pw1")
            p2 = st.text_input("Confirm password", type="password", key="reg_pw2")
            ok = st.form_submit_button("Send confirmation code", type="primary")
        if ok:
            if not u.strip():
                st.error("Username is required.")
                return
            if not EMAIL_RE.match(e.strip()):
                st.error("Please enter a valid email address.")
                return
            if len(p1) < 6:
                st.error("Password must be at least 6 characters.")
                return
            if p1 != p2:
                st.error("Passwords do not match.")
                return
            try:
                if _username_or_email_taken(u, e):
                    st.error("That username or email is already registered.")
                    return
            except Exception as err:
                st.error(f"Couldn't reach the user database: {err}")
                return

            code = f"{_secrets.randbelow(1_000_000):06d}"
            sent, msg = _send_confirmation_email(e.strip(), code)
            st.session_state.setup_pending = {
                "username": u.strip(),
                "email": e.strip(),
                "password": p1,
                "code": code,
                "expires_at": time.time() + CODE_TTL_SECONDS,
                "delivery": "email" if sent else "onscreen",
                "delivery_msg": msg,
            }
            st.rerun()
        return

    if time.time() > pending["expires_at"]:
        st.error("That code expired. Start over.")
        if st.button("Start over"):
            st.session_state.pop("setup_pending", None)
            st.rerun()
        return

    if pending["delivery"] == "email":
        st.success(pending["delivery_msg"])
    else:
        st.warning(pending["delivery_msg"])
        st.info(f"Confirmation code: **{pending['code']}** (valid for 15 minutes)")

    with st.form("confirm_form"):
        st.write(f"Code sent to **{pending['email']}**.")
        code_in = st.text_input("Enter 6-digit code", max_chars=6)
        c1, c2 = st.columns(2)
        with c1:
            confirm = st.form_submit_button("Confirm and create account", type="primary")
        with c2:
            cancel = st.form_submit_button("Cancel")
    if cancel:
        st.session_state.pop("setup_pending", None)
        st.rerun()
    if confirm:
        if not _secrets.compare_digest(code_in.strip(), pending["code"]):
            st.error("That code doesn't match.")
            return
        try:
            _append_user(pending["username"], pending["email"], pending["password"])
        except Exception as err:
            st.error(f"Couldn't save your account: {err}")
            return
        st.session_state.pop("setup_pending", None)
        st.success("Account created. Switch to the Sign in tab to log in.")


# ---------- Configuration gate ----------
def _config_status():
    """Returns a list of human-readable issues, empty list if ready."""
    issues = []
    try:
        if not st.secrets.get("smtp"):
            issues.append("Missing `[smtp]` section in Secrets (needed to email confirmation codes).")
    except (FileNotFoundError, AttributeError):
        issues.append("No secrets configured at all.")
    try:
        if not st.secrets.get("gsheets") or not st.secrets["gsheets"].get("sheet_id"):
            issues.append("Missing `[gsheets].sheet_id` in Secrets.")
    except (FileNotFoundError, AttributeError, KeyError):
        issues.append("Missing `[gsheets].sheet_id` in Secrets.")
    try:
        if not st.secrets.get("gcp_service_account"):
            issues.append("Missing `[gcp_service_account]` section in Secrets.")
    except (FileNotFoundError, AttributeError):
        issues.append("Missing `[gcp_service_account]` section in Secrets.")
    if not issues and _open_users_sheet() is None:
        issues.append("Couldn't open the Google Sheet — check that the service account has Editor access.")
    return issues


issues = _config_status()
if issues:
    st.error("This dashboard isn't fully configured yet.")
    with st.expander("How to fix this (admin)", expanded=True):
        st.write("Add the following entries to **Settings → Secrets** on Streamlit Community Cloud:")
        st.code(
            '[smtp]\n'
            'host = "smtp.gmail.com"\n'
            'port = 465\n'
            'user = "you@gmail.com"\n'
            'password = "16-char Gmail app password"\n'
            'from_name = "Terry\'s Event Schedule"\n\n'
            '[gsheets]\n'
            'sheet_id = "the-long-id-from-your-google-sheet-URL"\n\n'
            '[gcp_service_account]\n'
            '# Paste the contents of the Google Cloud service-account JSON\n'
            '# here as a TOML table — see DEPLOY_VIEWER.md for instructions.',
            language="toml",
        )
        st.markdown("**Currently missing:**")
        for x in issues:
            st.markdown(f"- {x}")
    st.stop()


# ---------- Auth gate ----------
if "auth_user" not in st.session_state:
    st.title("🔐 Terry's Event Schedule")
    _render_login()
    st.stop()


# ---------- Helpers (live time projection) ----------
def slot_for_ring(ring):
    return RING_SLOT_MINUTES.get(ring, DEFAULT_SLOT)


def division_colors(divisions_in_order):
    palette = [
        "#FFE5B4", "#B4E5FF", "#FFB4B4", "#FFFFB4", "#E5B4FF",
        "#FFC8B4", "#B4FFE5", "#FFB4E5", "#C8FFB4", "#B4C8FF",
    ]
    out, n = {}, len(palette)
    for i, d in enumerate(divisions_in_order):
        out[d] = palette[(i * 3) % n]
    return out


def _hhmm_to_min(t):
    try:
        h, m = str(t).split(":")
        return int(h) * 60 + int(m)
    except (ValueError, AttributeError):
        return None


def _min_to_hhmm(m):
    return f"{int(m // 60) % 24:02d}:{int(m % 60):02d}"


def _file_mtime(path):
    try:
        return path.stat().st_mtime
    except OSError:
        return 0


@st.cache_data(show_spinner=False)
def _load_schedule(mtime):
    if not STATE_PATH.exists():
        return pd.DataFrame()
    with open(STATE_PATH, "r", encoding="utf-8") as f:
        records = json.load(f)
    df = pd.DataFrame(records)
    if "score" not in df.columns:
        df["score"] = ""
    else:
        df["score"] = df["score"].fillna("")
    if "age_group" not in df.columns:
        df["age_group"] = ""
    return df


@st.cache_data(show_spinner=False)
def _load_sim_state(mtime):
    if not SIM_STATE_PATH.exists():
        return None
    with open(SIM_STATE_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def projected_overrides(schedule, sim_state):
    if not sim_state or sim_state.get("sim_wall_start") is None:
        return {}
    sim_running = sim_state.get("sim_running", False)
    sim_speed = sim_state.get("sim_speed", 1)
    paused_offset = sim_state.get("sim_paused_offset", 0)
    sim_wall_start = sim_state.get("sim_wall_start")
    if sim_running and sim_wall_start is not None:
        elapsed_real = time.time() - float(sim_wall_start)
        sim_seconds = paused_offset + elapsed_real * sim_speed
    else:
        sim_seconds = paused_offset
    total_min = sim_seconds / 60.0
    SIM_BASE = 9 * 60
    if total_min < 24 * 60:
        sim_day = "Saturday"
        sim_now_min = SIM_BASE + total_min
    else:
        sim_day = "Sunday"
        sim_now_min = SIM_BASE + (total_min - 24 * 60)
    sim_now_min = int(sim_now_min)

    sim_ring_state = sim_state.get("sim_ring_state", {})
    overrides = {}

    for ring in ALL_RINGS:
        if ring not in sim_ring_state:
            continue
        rs = sim_ring_state[ring]
        ring_slot = slot_for_ring(ring)
        log_by_eid = {e["entry_id"]: e for e in rs.get("log", [])}
        pending = rs.get("pending_score")
        started_at = rs.get("current_started_min")
        cur_idx = rs.get("current_idx", 0)
        ring_rows = (
            schedule[(schedule["ring"] == ring) & (schedule["day"] == sim_day)]
            .sort_values("order_in_ring")
            .reset_index(drop=True)
        )
        cursor = None
        for i in range(len(ring_rows)):
            row = ring_rows.iloc[i]
            eid = int(row["entry_id"])
            sched_start = _hhmm_to_min(row["start_time"])
            LUNCH_GAP_MIN = 30
            if cursor is not None and sched_start is not None and sched_start - cursor >= LUNCH_GAP_MIN:
                cursor = sched_start
            if eid in log_by_eid:
                entry = log_by_eid[eid]
                if entry["status"] == "absent":
                    overrides[eid] = (None, None, "❌")
                    if cursor is None or entry["finished_min"] > cursor:
                        cursor = entry["finished_min"]
                else:
                    overrides[eid] = (entry["started_min"], entry["finished_min"], "✅")
                    cursor = entry["finished_min"]
            elif pending is not None and pending["entry_id"] == eid:
                overrides[eid] = (pending["started_min"], pending["finished_min"], "📝")
                cursor = max(sim_now_min, int(pending["finished_min"]))
            elif i == cur_idx:
                if started_at is not None and started_at <= sim_now_min:
                    overrides[eid] = (started_at, started_at + ring_slot, "🟢")
                    cursor = started_at + ring_slot
                else:
                    base = cursor if cursor is not None else sim_now_min
                    proj_start = max(base, sim_now_min)
                    overrides[eid] = (proj_start, proj_start + ring_slot, "⏳")
                    cursor = proj_start + ring_slot
            else:
                base = cursor if cursor is not None else (sched_start or sim_now_min)
                overrides[eid] = (base, base + ring_slot, "")
                cursor = base + ring_slot
    return overrides


def apply_overrides(view_df, overrides):
    if not overrides:
        return view_df
    out = view_df.copy()
    for eid, (sm, em, marker) in overrides.items():
        mask = out["entry_id"] == eid
        if not mask.any():
            continue
        if sm is None:
            out.loc[mask, "start_time"] = f"{marker} —" if marker else "—"
            out.loc[mask, "end_time"] = "—"
        else:
            start_str = _min_to_hhmm(sm)
            end_str = _min_to_hhmm(em)
            out.loc[mask, "start_time"] = f"{marker} {start_str}".strip() if marker else start_str
            out.loc[mask, "end_time"] = end_str
    return out


# ---------- Main render ----------
header_l, header_r = st.columns([6, 1])
with header_l:
    if not st.session_state.get("_title_flashed"):
        st.session_state._title_flashed = True
        st.markdown(
            """
            <style>
            @keyframes pwn-title-color {
              0%, 49%   { color: #D81B60; }
              50%, 100% { color: #1F5FBF; }
            }
            .pwn-flash-h1 {
              animation: pwn-title-color 1s steps(1, end) 0s 10;
              animation-fill-mode: forwards;
              display: inline-block;
              font-weight: 700;
              font-size: 2.25rem;
              line-height: 1.2;
              padding: 0.4rem 0;
              margin: 0;
            }
            .pwn-flash-h1.done {
              animation: none;
              color: inherit;
            }
            </style>
            <h1 class="pwn-flash-h1">📋 Do your squats JANE! ❤️ — Live View</h1>
            """,
            unsafe_allow_html=True,
        )
        # st.markdown strips <script> tags for safety, so the swap-after-10s
        # script has to live inside an iframe component instead.
        st.components.v1.html(
            """
            <script>
            setTimeout(() => {
              try {
                const el = window.parent.document.querySelector('.pwn-flash-h1');
                if (el) {
                  el.classList.add('done');
                  el.textContent = '📋 Phoenix Wushu Nationals — Live View';
                }
              } catch (e) {}
            }, 10000);
            </script>
            """,
            height=0,
        )
    else:
        st.title("📋 Phoenix Wushu Nationals — Live View")
with header_r:
    st.caption(f"Signed in as **{st.session_state.auth_user}**")
    btn_l, btn_r = st.columns(2)
    with btn_l:
        if st.button("🔁 Refresh", key="vw_refresh", help="Reload the schedule without signing out", width="stretch"):
            _load_schedule.clear()
            _load_sim_state.clear()
            st.toast("Refreshed.", icon="🔁")
            st.rerun()
    with btn_r:
        if st.button("Sign out", key="logout", width="stretch"):
            st.session_state.pop("auth_user", None)
            st.rerun()

st.caption("Read-only mirror of the master schedule.")

schedule_mtime = _file_mtime(STATE_PATH)
if schedule_mtime == 0:
    st.error(
        f"No schedule file found at `{STATE_PATH}`. "
        "The host needs to commit `schedule_state.json` to the deployed repo."
    )
    st.stop()


# Promote any staged ring-button selection BEFORE the multiselect widget binds
# to vw_rings (writing widget-bound state after the widget is instantiated
# raises StreamlitAPIException, so we stage into pending_vw_rings here).
if "pending_vw_rings" in st.session_state:
    st.session_state.vw_rings = st.session_state.pop("pending_vw_rings")


# --- Ring controls live OUTSIDE the auto-refresh fragment so that clicks
# don't race with 2s ticks (which on mobile can briefly flash the old
# filter back over the new selection).
sched_mt = _file_mtime(STATE_PATH)
sim_mt = _file_mtime(SIM_STATE_PATH)
sched = _load_schedule(sched_mt)
sim = _load_sim_state(sim_mt)

sb_cols = st.columns([2, 2, 4])
with sb_cols[0]:
    if sim and sim.get("sim_running"):
        st.markdown("🟢 **Simulator: RUNNING**")
    elif sim and sim.get("sim_wall_start") is not None:
        st.markdown("🟡 **Simulator: PAUSED**")
    else:
        st.markdown("⚪ **Simulator: IDLE**")
with sb_cols[1]:
    sched_age = datetime.fromtimestamp(sched_mt).strftime("%H:%M:%S") if sched_mt else "—"
    sim_age = datetime.fromtimestamp(sim_mt).strftime("%H:%M:%S") if sim_mt else "—"
    st.caption(f"Schedule: {sched_age} · Sim: {sim_age}")
with sb_cols[2]:
    st.caption("⏱️ Auto-refreshing every 2s")

# Ring toggle buttons. Each button toggles its ring on/off. Active rings
# render in green. We stage into pending_vw_rings so the top-of-module
# promotion (above) writes vw_rings BEFORE the multiselect re-binds.
# These controls are at module scope (not inside the fragment), so a
# click triggers a single full app rerun without competing 2s ticks.
st.markdown("**Rings (click to toggle — green = active):**")
_inject_ring_button_styles()

_active_set = set(st.session_state.get("vw_rings", list(ALL_RINGS)))
_active_css = []
for ring in ALL_RINGS:
    if ring in _active_set:
        slug = ring.replace(" ", "_")
        _active_css.append(
            f'[class*="st-key-vw-ringbtn-{slug}"] button {{'
            f'  background-color: #2E7D32 !important;'
            f'  color: #FFFFFF !important;'
            f'  border-color: #1B5E20 !important;'
            f'}}'
            f'[class*="st-key-vw-ringbtn-{slug}"] button:hover {{'
            f'  background-color: #1B5E20 !important;'
            f'  color: #FFFFFF !important;'
            f'  border-color: #1B5E20 !important;'
            f'}}'
        )
if _active_css:
    st.markdown(f"<style>\n{chr(10).join(_active_css)}\n</style>", unsafe_allow_html=True)

btn_cols = st.columns(len(ALL_RINGS) + 2)
for col, ring in zip(btn_cols[:-2], ALL_RINGS):
    with col:
        slug = ring.replace(" ", "_")
        if st.button(_label_for_ring(ring), key=f"vw-ringbtn-{slug}", width="stretch"):
            current = list(st.session_state.get("vw_rings", list(ALL_RINGS)))
            if ring in current:
                current = [r for r in current if r != ring]
            else:
                new_set = set(current) | {ring}
                current = [r for r in ALL_RINGS if r in new_set]
            st.session_state.pending_vw_rings = current
            st.rerun()
with btn_cols[-2]:
    if st.button("⭐ All", key="vw-ringbtn-all", width="stretch", help="Activate all rings"):
        st.session_state.pending_vw_rings = list(ALL_RINGS)
        st.rerun()
with btn_cols[-1]:
    if st.button("✖ None", key="vw-ringbtn-none", width="stretch", help="Deactivate all rings"):
        st.session_state.pending_vw_rings = []
        st.rerun()

# Initialize the underlying state once so the rest of the app can read it.
if "vw_rings" not in st.session_state:
    st.session_state.vw_rings = list(ALL_RINGS)
ring_filter = st.session_state.vw_rings


@st.fragment(run_every="2s")
def _live_view():
    sched_mt = _file_mtime(STATE_PATH)
    sim_mt = _file_mtime(SIM_STATE_PATH)
    sched = _load_schedule(sched_mt)
    sim = _load_sim_state(sim_mt)
    overrides = projected_overrides(sched, sim)
    live_df = apply_overrides(sched, overrides)

    # Read the ring filter freshly from session state every tick so any
    # selection change made via the (out-of-fragment) controls takes effect
    # on the next paint, without re-rendering the controls themselves.
    ring_filter = st.session_state.get("vw_rings", list(ALL_RINGS))

    view_df = live_df
    if ring_filter:
        view_df = view_df[view_df["ring"].isin(ring_filter)]
    else:
        view_df = view_df.iloc[0:0]
    view_df = view_df.sort_values(["day", "ring", "order_in_ring"]).reset_index(drop=True)
    active_rings = [r for r in ALL_RINGS if r in ring_filter]
    multi_window_mode = len(active_rings) >= 2

    color_map = {}
    for ring in ALL_RINGS:
        ring_view = sched[sched["ring"] == ring].sort_values("order_in_ring")
        seen = []
        for d in ring_view["division"]:
            if d not in seen:
                seen.append(d)
        ring_colors = division_colors(seen)
        for div, color in ring_colors.items():
            color_map[(ring, div)] = color

    display_cols = [
        "ring", "start_time", "athlete", "division",
        "score", "age_group", "event_category",
    ]
    for c in display_cols:
        if c not in view_df.columns:
            view_df = view_df.assign(**{c: ""})

    # Compact styling for narrow (mobile) viewports — shrink padding/font and
    # let Athlete/Division wrap instead of forcing horizontal scroll.
    # Also: suppress the "stale" gray-out flash during the 2s auto-refresh so
    # the schedule stays readable instead of dimming on every tick.
    st.markdown(
        """
        <style>
        [data-stale="true"] { opacity: 1 !important; }
        .element-container[data-stale="true"] { opacity: 1 !important; }
        .pwn-table-wrap {
          max-height: 720px;
          overflow-y: auto;
          border: 1px solid rgba(0,0,0,0.08);
          border-radius: 6px;
        }
        table.pwn-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 0.92rem;
          font-variant-numeric: tabular-nums;
        }
        table.pwn-table thead th {
          position: sticky;
          top: 0;
          background: #fff;
          z-index: 2;
          text-align: left;
          padding: 6px 8px;
          border-bottom: 2px solid rgba(0,0,0,0.15);
          font-weight: 600;
        }
        table.pwn-table thead th.pwn-th-stacked {
          text-align: center;
          line-height: 1;
          letter-spacing: 0.05em;
          font-size: 0.85rem;
          padding: 4px 2px;
          width: 1.6em;
          min-width: 1.6em;
          max-width: 1.6em;
        }
        table.pwn-table td.pwn-stacked-cell {
          text-align: center;
          line-height: 1;
          font-variant-numeric: tabular-nums;
          padding: 4px 2px;
          width: 1.6em;
          min-width: 1.6em;
          max-width: 1.6em;
        }
        /* Athlete: keep each whitespace-separated name token (first / middle
           / last) intact on its own line — wrap on spaces only, never inside
           a name. Allows the column to stay narrow without breaking
           "Christopher" into "Christ-opher". */
        table.pwn-table td.pwn-athlete {
          word-break: keep-all;
          overflow-wrap: normal;
          white-space: normal;
        }
        table.pwn-table td {
          padding: 4px 8px;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          vertical-align: top;
        }
        table.pwn-table td.pwn-div { cursor: help; }
        @media (max-width: 768px) {
          table.pwn-table {
            font-size: 0.78rem;
            line-height: 1.15;
          }
          table.pwn-table td,
          table.pwn-table thead th {
            padding: 2px 4px;
            white-space: normal;
            word-break: break-word;
          }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    st.caption(
        "✅ done · 🟢 in progress · 📝 awaiting score · ⏳ ready · ❌ absent · "
        "no marker = future projection · "
        "💡 hover/long-press a Division cell to see the full text"
    )

    def _render_table(df_sub):
        display_df = df_sub[display_cols].rename(columns={
            "ring": "_Ring", "start_time": "Time",
            "athlete": "Athlete", "age_group": "Age",
            "event_category": "Event", "division": "Division", "score": "Score",
        })
        display_df["Athlete"] = display_df["Athlete"].apply(_normalize_name)

        # Build an HTML table directly so we can put a native `title` tooltip
        # on Division cells (st.dataframe has no per-cell tooltip support).
        # Native tooltips work on desktop hover and mobile long-press.
        cols = [c for c in display_df.columns if c != "_Ring"]
        rows_html = []
        for _, row in display_df.iterrows():
            ring = row["_Ring"]
            color = color_map.get((ring, row["Division"]), "#FFFFFF")
            cells = []
            for c in cols:
                val = "" if pd.isna(row[c]) else str(row[c])
                if c == "Division":
                    cells.append(
                        f'<td class="pwn-div" title="{html.escape(val)}">'
                        f'{html.escape(val)}</td>'
                    )
                elif c in ("Score", "Time"):
                    stacked = "<br>".join(html.escape(ch) for ch in val)
                    cells.append(f'<td class="pwn-stacked-cell">{stacked}</td>')
                elif c == "Athlete":
                    name_lines = "<br>".join(
                        html.escape(tok) for tok in val.split() if tok
                    )
                    cells.append(f'<td class="pwn-athlete">{name_lines}</td>')
                else:
                    cells.append(f"<td>{html.escape(val)}</td>")
            rows_html.append(
                f'<tr style="background-color:{color};color:#000;">'
                + "".join(cells) + "</tr>"
            )
        def _header_html(c):
            if c in ("Score", "Time"):
                stacked = "<br>".join(html.escape(ch) for ch in c)
                return f'<th class="pwn-th-stacked">{stacked}</th>'
            return f"<th>{html.escape(c)}</th>"

        header = "".join(_header_html(c) for c in cols)
        table_html = (
            '<div class="pwn-table-wrap">'
            f'<table class="pwn-table"><thead><tr>{header}</tr></thead>'
            f'<tbody>{"".join(rows_html)}</tbody></table></div>'
        )
        st.markdown(table_html, unsafe_allow_html=True)

    def _render_day(day_label):
        day_df = view_df[view_df["day"] == day_label]
        if not active_rings:
            st.info("No rings selected — click a ring button above (or **⭐ All**) to show schedules.")
            return
        if day_df.empty:
            st.info(f"No entries scheduled for {day_label}.")
            return

        if not multi_window_mode:
            _render_table(day_df)
            return

        # 2+ rings active → one window per ring, two-up grid.
        for row_start in range(0, len(active_rings), 2):
            row_rings = active_rings[row_start:row_start + 2]
            cols = st.columns(len(row_rings))
            for col, ring in zip(cols, row_rings):
                with col:
                    ring_color = RING_BORDER_COLORS.get(ring, "#666")
                    icon = RING_ICONS.get(ring, "")
                    st.markdown(
                        f'<div style="border-left:6px solid {ring_color};'
                        f'padding:6px 10px;margin:6px 0 4px;border-radius:4px;'
                        f'background:#f5f5f5;color:#222;font-weight:700;'
                        f'font-size:1.05rem;">{icon} {ring}</div>',
                        unsafe_allow_html=True,
                    )
                    ring_df = day_df[day_df["ring"] == ring]
                    if ring_df.empty:
                        st.caption("No entries for this day.")
                        continue
                    _render_table(ring_df)

    sat_tab, sun_tab = st.tabs(["Sat", "Sun"])
    with sat_tab:
        _render_day("Saturday")
    with sun_tab:
        _render_day("Sunday")


_live_view()
